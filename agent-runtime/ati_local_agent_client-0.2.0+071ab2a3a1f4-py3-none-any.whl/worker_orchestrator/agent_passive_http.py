"""Tools-off inference over bounded HTTP exchanges with durable result delivery."""

import asyncio
import hashlib
import json
import logging
import math
import re
import time
from urllib.parse import urlsplit, urlunsplit

import httpx

from .agent_session_store import SessionProtocolError, canonical


def inference_url(reverse):
    peer = urlsplit(reverse)
    if (
        peer.scheme != "wss"
        or not peer.hostname
        or peer.username
        or peer.password
        or peer.query
        or peer.fragment
        or not peer.path.endswith("/agent/connect")
    ):
        raise SessionProtocolError("AGENT_REVERSE_REQUIRES_TLS")
    return urlunsplit(
        ("https", peer.netloc, peer.path[: -len("/agent/connect")] + "/agent/inference", "", "")
    )


class PassiveHttpWorker:
    def __init__(
        self, url, provider, journal, certificate, inference, *, transport=None, retry_delay=1
    ):
        self.url, self.provider, self.db, self.certificate, self.inference = (
            url,
            provider,
            journal.db,
            certificate,
            inference,
        )
        self.transport = transport
        self.retry_delay = retry_delay
        self.db.execute("""CREATE TABLE IF NOT EXISTS passive_inference_receipts(
            scope TEXT NOT NULL,id TEXT NOT NULL,input_hash TEXT NOT NULL,state TEXT NOT NULL,
            result TEXT,expires REAL NOT NULL,PRIMARY KEY(scope,id))""")

    async def execute(self, scope, packet):
        if (
            not isinstance(packet, dict)
            or set(packet) != {"id", "model", "messages", "timeout", "expiresAt"}
            or not re.fullmatch(r"[a-f0-9]{32}", str(packet.get("id", "")))
            or packet["model"] != self.provider
            or not isinstance(packet["timeout"], int)
            or isinstance(packet["timeout"], bool)
            or not 1 <= packet["timeout"] <= 300
            or not isinstance(packet["expiresAt"], int | float)
            or isinstance(packet["expiresAt"], bool)
            or not math.isfinite(packet["expiresAt"])
            or len(canonical(packet).encode()) >= 256000
            or not isinstance(packet["messages"], list)
            or not packet["messages"]
            or any(
                not isinstance(m, dict)
                or set(m) != {"role", "content"}
                or m["role"] not in {"system", "user", "assistant"}
                or not isinstance(m["content"], str)
                for m in packet["messages"]
            )
        ):
            raise SessionProtocolError("LOCAL_AGENT_INVALID_RESPONSE")
        identity = packet["id"]
        hashed = hashlib.sha256(canonical(packet).encode()).hexdigest()
        self.db.execute("DELETE FROM passive_inference_receipts WHERE expires<?", (time.time(),))
        row = self.db.execute(
            "SELECT input_hash,state,result FROM passive_inference_receipts WHERE scope=? AND id=?",
            (scope, identity),
        ).fetchone()
        if row:
            if row["input_hash"] != hashed:
                raise SessionProtocolError("AGENT_IDEMPOTENCY_CONFLICT")
            if row["result"]:
                return json.loads(row["result"])
            # A process restart cannot establish an unreceipted CLI outcome.
            result = {"error": "AGENT_OUTCOME_UNKNOWN"}
        else:
            if (
                self.db.execute("SELECT COUNT(*) FROM passive_inference_receipts").fetchone()[0]
                >= 256
            ):
                return {"error": "LOCAL_AGENT_BUSY"}
            self.db.execute(
                "INSERT INTO passive_inference_receipts VALUES(?,?,?,?,?,?)",
                (scope, identity, hashed, "started", None, time.time() + 900),
            )
            try:
                remaining = min(packet["timeout"], packet["expiresAt"] - time.time())
                if remaining <= 0:
                    raise TimeoutError()
                async with asyncio.timeout(remaining):
                    result = await self.inference(packet)
                if (
                    not isinstance(result, dict)
                    or not result
                    or set(result) - {"text", "error"}
                    or any(not isinstance(v, str) for v in result.values())
                ):
                    result = {"error": "LOCAL_AGENT_INVALID_RESPONSE"}
                if len(canonical(result).encode()) >= 480000:
                    result = {"error": "LOCAL_AGENT_OUTPUT_TOO_LARGE"}
            except TimeoutError:
                result = {"error": "LOCAL_AGENT_TIMEOUT"}
            except asyncio.CancelledError:
                raise
            except Exception:
                result = {"error": "LOCAL_AGENT_REQUEST_FAILED"}
        self.db.execute(
            "UPDATE passive_inference_receipts SET state=?,result=? WHERE scope=? AND id=?",
            ("completed", canonical(result), scope, identity),
        )
        return result

    async def run(self):
        session = None
        pending = None
        failures = 0
        async with httpx.AsyncClient(
            transport=self.transport, timeout=httpx.Timeout(30, read=30), trust_env=False
        ) as client:
            while True:
                try:
                    if session is None or session["expiresAt"] <= time.time() + 5:
                        response = await client.get(self.url + "/challenge")
                        response.raise_for_status()
                        challenge = response.json()
                        proof = await self.certificate(challenge["challenge"], challenge["target"])
                        response = await client.post(
                            self.url + "/session",
                            json={"challenge": challenge["challenge"], "certificate": proof},
                        )
                        response.raise_for_status()
                        session = response.json()
                        if not re.fullmatch(r"[a-f0-9]{64}", str(session.get("scope", ""))):
                            raise SessionProtocolError("AGENT_HTTP_SESSION_INVALID")
                        if pending and pending["scope"] != session["scope"]:
                            pending = (
                                None  # Never deliver an old owner's evidence into a new binding.
                            )
                    headers = {"Authorization": "AgentInference " + session["token"]}
                    if pending:
                        response = await client.post(
                            self.url + "/result",
                            headers=headers,
                            json={"id": pending["id"], "result": pending["result"]},
                        )
                        if response.status_code == 410:
                            pending = None
                            continue
                        response.raise_for_status()
                        pending = None
                    else:
                        response = await client.post(self.url + "/claim", headers=headers, json={})
                        response.raise_for_status()
                        packet = response.json().get("request")
                        if packet is not None:
                            result = await self.execute(session["scope"], packet)
                            pending = dict(id=packet["id"], scope=session["scope"], result=result)
                    failures = 0
                except asyncio.CancelledError:
                    raise
                except httpx.HTTPStatusError as error:
                    if error.response.status_code in {401, 403}:
                        session = None
                    failures += 1
                    await asyncio.sleep(self.retry_delay * min(10, 2 ** min(failures, 3)))
                except (httpx.HTTPError, ValueError, KeyError, TypeError) as error:
                    logging.getLogger(__name__).warning(
                        "Passive inference delivery reconnect: %s", type(error).__name__
                    )
                    failures += 1
                    await asyncio.sleep(self.retry_delay * min(10, 2 ** min(failures, 3)))
