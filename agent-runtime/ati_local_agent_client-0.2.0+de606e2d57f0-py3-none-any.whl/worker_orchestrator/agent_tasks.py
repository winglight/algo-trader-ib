"""Agent-container schedules. No trading database, strategy or broker client."""
import asyncio
from contextlib import suppress
import json
import math
import time
from uuid import uuid4
from .agent_session_store import SessionProtocolError,canonical

METHODS=frozenset({'task.list','task.create','task.update','task.cancel'})

class AgentTasks:
    def __init__(self,runtime):
        self.runtime=runtime;self.db=runtime.journal.db;self.wake=asyncio.Event();self.runner=None
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS agent_tasks(id TEXT PRIMARY KEY,owner TEXT NOT NULL,session_id TEXT NOT NULL,
          title TEXT NOT NULL,prompt TEXT NOT NULL,next_run REAL,interval_seconds INTEGER,enabled INTEGER NOT NULL DEFAULT 0,
          version INTEGER NOT NULL DEFAULT 1,state TEXT NOT NULL DEFAULT 'paused',last_turn TEXT,last_error TEXT,
          created REAL NOT NULL,updated REAL NOT NULL);
        CREATE INDEX IF NOT EXISTS agent_task_clock ON agent_tasks(enabled,next_run);
        CREATE TABLE IF NOT EXISTS agent_task_runs(id TEXT PRIMARY KEY,task_id TEXT NOT NULL,scheduled REAL NOT NULL,
          state TEXT NOT NULL,turn_id TEXT,started REAL NOT NULL,finished REAL,error TEXT);
        ''')
        # A send without its native acknowledgement is never automatically replayed.
        self.db.execute("UPDATE agent_tasks SET enabled=0,state='outcome_unknown',last_error='AGENT_OUTCOME_UNKNOWN' WHERE id IN (SELECT task_id FROM agent_task_runs WHERE state='starting')")
        self.db.execute("UPDATE agent_task_runs SET state='outcome_unknown',error='AGENT_OUTCOME_UNKNOWN',finished=? WHERE state='starting'",(time.time(),))

    def emit(self,job):
        self.runtime.journal.append_event(job['owner'],job['session_id'],dict(method='ati/taskChanged',params=dict(taskId=job['id'],state=job['state'],version=job['version'])))
        for queue in tuple(self.runtime.listeners):
            if queue.empty():queue.put_nowait(True)
        self.wake.set()

    def get(self,owner,session,identity):
        row=self.db.execute('SELECT * FROM agent_tasks WHERE id=? AND owner=? AND session_id=?',(identity,owner,session)).fetchone()
        if row is None:raise SessionProtocolError('AGENT_TASK_NOT_FOUND')
        return dict(row)

    def public(self,job):
        runs=[dict(id=row['id'],scheduledAt=row['scheduled'],state=row['state'],nativeTurnId=row['turn_id'],startedAt=row['started'],finishedAt=row['finished'],error=row['error']) for row in self.db.execute('SELECT * FROM agent_task_runs WHERE task_id=? ORDER BY started DESC LIMIT 10',(job['id'],))]
        return dict(id=job['id'],title=job['title'],text=job['prompt'],nextRunAt=job['next_run'],intervalSeconds=job['interval_seconds'],enabled=bool(job['enabled']),version=job['version'],state=job['state'],nativeTurnId=job['last_turn'],error=job['last_error'],runs=runs)

    def command(self,owner,session,method,params):
        if method=='task.list':
            if params:raise SessionProtocolError('AGENT_COMMAND_INVALID')
            return dict(items=[self.public(dict(row)) for row in self.db.execute('SELECT * FROM agent_tasks WHERE owner=? AND session_id=? ORDER BY created DESC LIMIT 100',(owner,session))])
        allowed={'title','text','nextRunAt','intervalSeconds'}
        if method=='task.create':
            if set(params)!=allowed:raise SessionProtocolError('AGENT_COMMAND_INVALID')
            if self.db.execute("SELECT COUNT(*) FROM agent_tasks WHERE owner=? AND state!='canceled'",(owner,)).fetchone()[0]>=100:raise SessionProtocolError('AGENT_BACKPRESSURE')
            job=dict(id=uuid4().hex,owner=owner,session_id=session,title=params['title'],prompt=params['text'],next_run=params['nextRunAt'],interval_seconds=params['intervalSeconds'],enabled=0,version=1,state='paused',last_turn=None,last_error=None,created=time.time(),updated=time.time())
        else:
            if set(params)-({'taskId','expectedVersion','enabled'}|allowed) or not {'taskId','expectedVersion'}<=set(params):raise SessionProtocolError('AGENT_COMMAND_INVALID')
            job=self.get(owner,session,params['taskId'])
            if type(params['expectedVersion']) is not int or params['expectedVersion']!=job['version']:raise SessionProtocolError('AGENT_TASK_VERSION_CHANGED')
            if job['state']=='canceled':raise SessionProtocolError('AGENT_TASK_CANCELED')
            for key,column in [('title','title'),('text','prompt'),('nextRunAt','next_run'),('intervalSeconds','interval_seconds')]:
                if key in params:job[column]=params[key]
            if 'enabled' in params:
                if type(params['enabled']) is not bool:raise SessionProtocolError('AGENT_COMMAND_INVALID')
                job['enabled']=int(params['enabled'])
            job.update(version=job['version']+1,updated=time.time())
            if method=='task.cancel':
                if set(params)!={'taskId','expectedVersion'}:raise SessionProtocolError('AGENT_COMMAND_INVALID')
                job.update(enabled=0,state='canceled')
            else:job['state']='scheduled' if job['enabled'] else 'paused'
        if (not isinstance(job['title'],str) or not 1<=len(job['title'].strip())<=120 or not isinstance(job['prompt'],str) or not 1<=len(job['prompt'].strip())<=32000
            or type(job['next_run']) not in {int,float} or not math.isfinite(job['next_run'])
            or job['next_run']>time.time()+366*86400
            or (job['interval_seconds'] is not None and (type(job['interval_seconds']) is not int or not 60<=job['interval_seconds']<=30*86400))):raise SessionProtocolError('AGENT_TASK_INVALID')
        if job['enabled'] and job['next_run']<=time.time():raise SessionProtocolError('AGENT_TASK_TIME_PAST')
        if method=='task.create':
            columns=list(job)
            self.db.execute('INSERT INTO agent_tasks('+','.join(columns)+') VALUES ('+','.join('?' for _ in columns)+')',[job[key] for key in columns])
        else:
            columns=[key for key in job if key not in {'id','owner','session_id','created'}]
            self.db.execute('UPDATE agent_tasks SET '+','.join(key+'=?' for key in columns)+' WHERE id=?',[job[key] for key in columns]+[job['id']])
        self.emit(job);return self.public(job)

    async def start(self):
        await self.recover()
        self.runner=asyncio.create_task(self.clock())

    async def close(self):
        if self.runner:
            self.runner.cancel()
            with suppress(asyncio.CancelledError):await self.runner

    async def recover(self):
        for row in self.db.execute("SELECT DISTINCT t.owner,t.session_id FROM agent_tasks t JOIN agent_task_runs r ON r.task_id=t.id WHERE r.state='running'").fetchall():
            try:
                session=self.runtime.journal.session(row['owner'],row['session_id'])
                result=await self.runtime._execute(row['owner'],row['session_id'],'session.read',{},session['epoch'])
                for turn in result.get('turns',[]):
                    if turn['status']!='inProgress':self.completed(session['native_id'],turn['id'],turn['status'])
            except Exception:
                self.db.execute("UPDATE agent_tasks SET enabled=0,state='outcome_unknown',last_error='AGENT_OUTCOME_UNKNOWN' WHERE owner=? AND session_id=?",(row['owner'],row['session_id']))

    async def clock(self):
        while True:
            self.wake.clear()
            await self.run_due()
            due=self.db.execute('SELECT MIN(next_run) FROM agent_tasks WHERE enabled=1').fetchone()[0]
            delay=max(1,min(60,(due-time.time()) if due is not None else 60))
            try:
                async with asyncio.timeout(delay):await self.wake.wait()
            except TimeoutError:pass

    async def run_due(self):
        for row in self.db.execute('SELECT * FROM agent_tasks WHERE enabled=1 AND next_run<=? ORDER BY next_run LIMIT 16',(time.time(),)).fetchall():
            job=dict(row);owner,identity=job['owner'],job['session_id']
            async with self.runtime.locks.setdefault((owner,identity),asyncio.Lock()):
                job=self.get(owner,identity,job['id'])
                session=self.runtime.journal.session(owner,identity)
                if not job['enabled'] or session['active_turn'] or self.db.execute("SELECT 1 FROM agent_task_runs r JOIN agent_tasks t ON t.id=r.task_id WHERE t.owner=? AND t.session_id=? AND r.state IN ('starting','running')",(owner,identity)).fetchone():continue
                run=uuid4().hex;now=time.time();interval=job['interval_seconds']
                next_run=job['next_run']+interval*(math.floor((now-job['next_run'])/interval)+1) if interval else job['next_run']
                self.db.execute('BEGIN IMMEDIATE')
                try:
                    self.db.execute("INSERT INTO agent_task_runs VALUES (?,?,?,'starting',NULL,?,NULL,NULL)",(run,job['id'],job['next_run'],now))
                    self.db.execute("UPDATE agent_tasks SET enabled=?,next_run=?,state='running',last_error=NULL,updated=? WHERE id=?",(int(interval is not None),next_run,now,job['id']))
                    self.db.execute('COMMIT')
                except BaseException:self.db.execute('ROLLBACK');raise
                try:
                    result=await self.runtime._execute(owner,identity,'turn.start',dict(text=canonical(dict(schema='ati.agent.scheduled-task/1',taskId=job['id'],runId=run,userMessage=job['prompt'],executionPolicy='This is an Agent-owned scheduled request, not a system strategy. Use only authorized MCP tools and current native evidence. Orders must be attributed to Agent. Never bypass Risk, expired permissions or missing broker connectivity.'))),session['epoch'])
                    turn=result['nativeTurnId']
                    self.db.execute("UPDATE agent_task_runs SET state='running',turn_id=? WHERE id=?",(turn,run))
                    self.db.execute('UPDATE agent_tasks SET last_turn=? WHERE id=?',(turn,job['id']))
                    # Very short turns may complete before turn/start returns.
                    packet=self.db.execute("SELECT payload FROM events WHERE owner=? AND session_id=? AND json_extract(payload,'$.method')='turn/completed' AND json_extract(payload,'$.params.turn.id')=? ORDER BY seq DESC LIMIT 1",(owner,identity,turn)).fetchone()
                    if packet:self.completed(session['native_id'],turn,json.loads(packet['payload'])['params']['turn']['status'])
                except asyncio.CancelledError:raise
                except Exception:
                    self.db.execute("UPDATE agent_task_runs SET state='outcome_unknown',error='AGENT_OUTCOME_UNKNOWN',finished=? WHERE id=?",(time.time(),run))
                    self.db.execute("UPDATE agent_tasks SET enabled=0,state='outcome_unknown',last_error='AGENT_OUTCOME_UNKNOWN' WHERE id=?",(job['id'],))
                self.emit(self.get(owner,identity,job['id']))

    def completed(self,native,turn,status):
        self.runtime.journal.db.execute('UPDATE sessions SET active_turn=NULL WHERE native_id=? AND active_turn=?',(native,turn))
        jobs=self.db.execute("SELECT t.* FROM agent_tasks t JOIN sessions s ON s.owner=t.owner AND s.id=t.session_id JOIN agent_task_runs r ON r.task_id=t.id WHERE s.native_id=? AND r.turn_id=? AND r.state='running'",(native,turn)).fetchall()
        for row in jobs:
            self.db.execute("UPDATE agent_task_runs SET state=?,finished=? WHERE task_id=? AND turn_id=? AND state='running'",(status,time.time(),row['id'],turn))
            state='canceled' if row['state']=='canceled' else 'scheduled' if row['enabled'] else status
            self.db.execute('UPDATE agent_tasks SET state=?,updated=? WHERE id=?',(state,time.time(),row['id']))
            self.emit(self.get(row['owner'],row['session_id'],row['id']))
