"""JSON stdio bridge to the user's authenticated Codex CLI.

Uses the documented non-interactive command and final-message file:
https://learn.chatgpt.com/docs/non-interactive-mode
No model account, API key, or subscription credential is handled by ATI.
"""
import json
import base64
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path


PASSIVE_FLAGS = (
    '--ignore-user-config', '--ignore-rules', '--json', '-c', 'web_search="disabled"',
    '-c', 'mcp_servers={}',
    *(argument for feature in (
        'shell_tool', 'unified_exec', 'apps', 'plugins', 'hooks', 'browser_use',
        'browser_use_external', 'browser_use_full_cdp_access', 'computer_use',
        'in_app_browser', 'image_generation', 'view_image', 'multi_agent', 'multi_agent_v2',
    ) for argument in ('--disable', feature)),
)


def passive_failure(events):
    error = warning = ''
    for line in events.splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if not isinstance(event, dict):
            continue
        if event.get('type') == 'turn.failed' and isinstance(event.get('error'), dict):
            error = str(event['error'].get('message', ''))
        elif event.get('type') == 'error':
            warning = str(event.get('message', ''))
        elif event.get('type') == 'turn.completed':
            error = warning = ''
    message = (error or warning).lower()
    if re.search(r'\b(?:401 unauthorized|403 forbidden|authentication failed|not logged in|token refresh failed)\b', message):
        return 'LOCAL_AGENT_AUTH_FAILED'
    if re.search(r'\b(?:429 too many requests|rate limit exceeded|usage limit|insufficient quota)\b', message):
        return 'LOCAL_AGENT_RATE_LIMITED'
    if re.search(r'\b(?:stream disconnected before completion|connection reset by peer|error sending request|'
                 r'connection timed out|request timed out|502 bad gateway|503 service unavailable|504 gateway timeout)\b', message):
        return 'LOCAL_AGENT_NETWORK_FAILED'
    return 'LOCAL_AGENT_EXIT_FAILED'


def run_passive(command, prompt, directory, output, budget):
    deadline = time.monotonic() + budget
    for attempt in range(1, 3):
        try:
            with tempfile.TemporaryFile(dir=directory) as events:
                completed = subprocess.run(command, input=prompt, text=True, cwd=directory,
                                           stdout=events, stderr=subprocess.DEVNULL, check=False,
                                           timeout=max(0.01, deadline - time.monotonic()))
                if not completed.returncode:
                    if not output.is_file() or not output.stat().st_size:
                        return 'LOCAL_AGENT_EMPTY_RESPONSE'
                    return None
                events.seek(max(0, events.tell() - 128_000))
                code = passive_failure(events.read())
        except subprocess.TimeoutExpired:
            code = 'LOCAL_AGENT_TIMEOUT'
        except FileNotFoundError:
            return 'LOCAL_AGENT_NOT_INSTALLED'
        if (code != 'LOCAL_AGENT_NETWORK_FAILED' or attempt == 2 or output.exists()
                or deadline - time.monotonic() < 40):
            return code
    return 'LOCAL_AGENT_EXIT_FAILED'


def attach_images(value, directory, arguments, *, depth=0):
    """Materialize bounded image inputs, including JSON encoded frozen packets."""
    if depth > 16:
        raise ValueError('AGENT_INPUT_TOO_DEEP')
    if isinstance(value, dict):
        return {key: attach_images(item, directory, arguments, depth=depth + 1) for key, item in value.items()}
    if isinstance(value, list):
        return [attach_images(item, directory, arguments, depth=depth + 1) for item in value]
    if isinstance(value, str) and value.startswith('data:image/'):
        header, data = value.split(',', 1)
        extensions = {'data:image/png;base64': 'png', 'data:image/jpeg;base64': 'jpg', 'data:image/webp;base64': 'webp'}
        if header not in extensions or len(arguments) >= 32:
            raise ValueError('AGENT_IMAGE_FORMAT_UNSUPPORTED')
        content = base64.b64decode(data, validate=True)
        if len(content) > 10 * 1024 * 1024:
            raise ValueError('AGENT_IMAGE_TOO_LARGE')
        path = directory / ('input-' + str(len(arguments)) + '.' + extensions[header])
        path.write_bytes(content)
        arguments.extend(['--image', str(path)])
        return str(path)
    # Text-only frozen contracts can contain deeply nested JSON schemas. They
    # are prompts, not image trees: preserve them verbatim instead of applying
    # the image traversal depth limit to the embedded schema.
    if isinstance(value, str) and value[:1] in {'{', '['} and 'data:image/' in value:
        try:
            parsed = json.loads(value)
        except ValueError:
            return value
        return json.dumps(attach_images(parsed, directory, arguments, depth=depth + 1), ensure_ascii=False)
    return value


def main():
    packet = json.load(sys.stdin)
    passive = sys.argv[1:] == ['--passive-inference']
    with tempfile.TemporaryDirectory(prefix='ati-agent-') as work:
        output = Path(work) / 'answer.txt'
        images = []
        variables = attach_images(packet.get('variables', {}), Path(work), images)
        prompt = (packet['prompt'] + '\n\nFrozen operation inputs:\n' +
                  json.dumps(variables, ensure_ascii=False) +
                  '\n\nReturn the final answer required by the operation. Do not change files or perform trading actions.')
        command = ['codex', 'exec', '--ephemeral', '--skip-git-repo-check', '--sandbox', 'read-only',
                   '--output-last-message', str(output), *images]
        if passive:
            code = run_passive([*command, *PASSIVE_FLAGS, '-'], prompt, work, output,
                               packet['budget'])
            if code:
                json.dump({'error': code}, sys.stdout)
                return
        else:
            completed = subprocess.run([*command, '-'],
                                  input=prompt, text=True, cwd=work, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.PIPE, check=False)
            if completed.returncode:
                print('Codex adapter failed; check Codex login and local diagnostics.', file=sys.stderr)
                raise SystemExit(completed.returncode)
        text = output.read_text().strip()
        try:
            structured = json.loads(text)
        except ValueError:
            structured = None
        json.dump({'text': text, 'json_payload': structured, 'model': 'user-codex'}, sys.stdout)


if __name__ == '__main__':
    main()
