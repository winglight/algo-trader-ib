"""Bounded v2 channel used by private Unix sockets and outbound TLS WebSockets.

Only the configured backend can use a reverse connection. The Cloud device
credential is sent to Cloud alone; the backend receives a nonce-bound proof.
"""
import asyncio
from contextlib import suppress
import base64
import hashlib
import json
import time
import re
from .agent_session_store import SessionProtocolError,canonical

OWNER=re.compile(r'^[0-9a-f]{64}$')


def decode(value):
    if not isinstance(value,str) or len(value)>65536:raise ValueError()
    return base64.b64decode(value+'='*(-len(value)%4),altchars=b'-_',validate=True)


def verify_product(envelope,binding,keys,now):
    # Standalone public client deliberately does not import private application
    # packages. Cross-package contract tests use SDK-signed actual certificates.
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    try:
        if type(envelope['version']) is not int or envelope['version']!=1:raise ValueError()
        kid=envelope['keyId'];payload=envelope['payload']
        Ed25519PublicKey.from_public_bytes(decode(keys[kid])).verify(decode(envelope['signature']),b'ati.optional-products/1\x00'+kid.encode()+b'\x00'+payload.encode())
        claims=json.loads(decode(payload))
        if claims.get('iss')!='ati-cloud-platform' or claims.get('aud')!='ati-local-products':raise ValueError()
        if any(type(claims.get(key)) is not int for key in ('iat','nbf','exp')) or claims['iat']>now or claims['nbf']>now or claims['exp']<=now:raise ValueError()
        if any(not isinstance(binding.get(key),str) or not binding[key] or claims.get(key)!=binding[key] for key in ('installationId','environmentId','tenantId','userId','leaseId','bindingGeneration')):raise ValueError()
        if claims.get('features',{}).get('copilot') is not True:raise ValueError()
        return claims
    except (ValueError,TypeError,KeyError,AttributeError,InvalidSignature):raise SessionProtocolError('AGENT_PRODUCT_AUTHORIZATION_REQUIRED') from None


class SessionChannel:
    def __init__(self,runtime,certificate,public_keys,*,inference=None):
        self.runtime,self.certificate,self.public_keys=runtime,certificate,public_keys
        self.inference=inference
        self.inflight=set()

    async def serve(self,receive,send):
        async with asyncio.timeout(15):hello=await receive()
        if (not isinstance(hello,dict) or hello.get('type')!='hello' or not isinstance(hello.get('binding'),dict)
            or not isinstance(hello.get('challenge'),str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,128}',hello['challenge'])
            or hello.get('provider')!=self.runtime.provider):raise SessionProtocolError('AGENT_HANDSHAKE_INVALID')
        binding=hello['binding']
        claims=verify_product(hello.get('productGrant'),binding,self.public_keys(),int(time.time()))
        proof=await self.certificate(hello['challenge'],binding)
        prefix=hashlib.sha256(canonical([binding['installationId'],binding['tenantId'],binding['userId']]).encode()).hexdigest()+'.'
        deadline=min(claims['exp'],time.time()+90)
        lock=asyncio.Lock()
        async def write(value):
            async with lock:
                try:
                    async with asyncio.timeout(15):await send(value)
                except Exception:raise ConnectionError('AGENT_CHANNEL_CLOSED') from None
        await write(dict(type='hello',certificate=proof,capabilities=dict(self.runtime.capabilities(),passiveInference=self.inference is not None)))
        async with asyncio.timeout(15):subscription=await receive()
        if not isinstance(subscription,dict) or subscription.get('type')!='subscribe':raise SessionProtocolError('AGENT_SUBSCRIPTION_REQUIRED')
        cursor=subscription.get('after',0)
        if type(cursor) is not int or cursor<0:raise SessionProtocolError('AGENT_CURSOR_INVALID')
        queue=asyncio.Queue(maxsize=1);self.runtime.listeners.add(queue)
        inferences=set()
        async def outbox():
            nonlocal cursor
            while time.time()<deadline or inferences:
                rows=self.runtime.journal.db.execute('SELECT seq,owner,session_id,payload FROM events WHERE owner LIKE ? AND seq>? ORDER BY seq LIMIT 100',(prefix+'%',cursor)).fetchall()
                for row in rows:
                    await write(dict(type='event',sequence=row['seq'],owner=row['owner'][len(prefix):],sessionId=row['session_id'],payload=json.loads(row['payload'])))
                    cursor=row['seq']
                if len(rows)==100:continue
                # Durable outbox recovery, not browser or business-state polling.
                try:
                    async with asyncio.timeout(min(10,max(.01,deadline-time.time())) if time.time()<deadline else 10):await queue.get()
                except asyncio.TimeoutError:await write({'type':'heartbeat'})
        async def command(packet):
            identity=packet.get('id')
            try:
                if not isinstance(identity,str) or not 1<=len(identity)<=128 or not OWNER.fullmatch(packet.get('owner','')):raise SessionProtocolError('AGENT_COMMAND_INVALID')
                result=await self.runtime.execute(prefix+packet['owner'],packet.get('command'))
                await write(dict(type='receipt',id=identity,**result))
            except SessionProtocolError as error:
                await write(dict(type='receipt',id=identity,state='rejected',result={'code':str(error)}))
            except (ConnectionError,OSError,asyncio.TimeoutError):pass
            except Exception:
                with suppress(ConnectionError):await write(dict(type='receipt',id=identity,state='outcome_unknown',result={'code':'AGENT_OUTCOME_UNKNOWN'}))
        async def infer(packet):
            identity=packet.get('id')
            result={'error':'LOCAL_AGENT_INVALID_RESPONSE'}
            try:
                messages=packet.get('messages');timeout=packet.get('timeout')
                if (self.inference is None or not isinstance(identity,str) or not re.fullmatch(r'[a-f0-9]{32}',identity)
                    or set(packet)!={'type','id','model','messages','timeout'} or packet['model']!=self.runtime.provider
                    or type(timeout) is not int or not 1<=timeout<=300 or len(canonical(packet).encode())>=256000
                    or not isinstance(messages,list) or not messages or any(not isinstance(message,dict)
                    or set(message)!={'role','content'} or message['role'] not in {'system','user','assistant'}
                    or not isinstance(message['content'],str) for message in messages)):
                    raise SessionProtocolError('LOCAL_AGENT_INVALID_RESPONSE')
                async with asyncio.timeout(timeout):result=await self.inference(packet)
                if not isinstance(result,dict) or set(result)-{'text','error'}:result={'error':'LOCAL_AGENT_INVALID_RESPONSE'}
                if len(canonical(result).encode())>=480000:result={'error':'LOCAL_AGENT_OUTPUT_TOO_LARGE'}
            except asyncio.TimeoutError:result={'error':'LOCAL_AGENT_TIMEOUT'}
            except Exception:result={'error':'LOCAL_AGENT_REQUEST_FAILED'}
            with suppress(ConnectionError,OSError):await write(dict(type='inference.result',id=identity,result=result))
        delivery=asyncio.create_task(outbox())
        try:
            while time.time()<deadline:
                async with asyncio.timeout(max(.01,deadline-time.time())):packet=await receive()
                if not isinstance(packet,dict):raise SessionProtocolError('AGENT_FRAME_INVALID')
                if packet.get('type')=='command':
                    if len(self.inflight)>=64:raise SessionProtocolError('AGENT_BACKPRESSURE')
                    task=asyncio.create_task(command(packet));self.inflight.add(task);task.add_done_callback(self.inflight.discard)
                elif packet.get('type')=='inference':
                    if len(self.inflight)>=64:raise SessionProtocolError('AGENT_BACKPRESSURE')
                    task=asyncio.create_task(infer(packet));self.inflight.add(task);inferences.add(task)
                    task.add_done_callback(self.inflight.discard);task.add_done_callback(inferences.discard)
                elif packet.get('type')=='ack':
                    if type(packet.get('sequence')) is not int or not 0<=packet['sequence']<=cursor:raise SessionProtocolError('AGENT_ACK_INVALID')
                    self.runtime.journal.acknowledge(prefix,packet['sequence'])
                else:raise SessionProtocolError('AGENT_FRAME_INVALID')
                if delivery.done():await delivery
        except asyncio.TimeoutError:
            if time.time()<deadline:raise
        finally:
            if time.time()>=deadline and inferences:
                # Finish the already-authorized one-shot request while sending
                # heartbeats; admit no further work under the expiring proof.
                with suppress(ConnectionError,OSError):await write({'type':'draining'})
                await asyncio.gather(*tuple(inferences),return_exceptions=True)
            delivery.cancel()
            with suppress(asyncio.CancelledError):await delivery
            self.runtime.listeners.discard(queue)
            # Commands keep running and store their receipt even if the socket
            # disappears. Never cancel a native tool because a browser closed.


async def stream_channel(channel,reader,writer):
    async def receive():
        raw=await reader.readline()
        if not raw:raise ConnectionError()
        if len(raw)>512000:raise SessionProtocolError('AGENT_FRAME_TOO_LARGE')
        return json.loads(raw)
    async def send(value):
        writer.write(canonical(value).encode()+b'\n');await writer.drain()
    try:await channel.serve(receive,send)
    except (ValueError,ConnectionError,OSError,asyncio.TimeoutError):pass
    finally:
        writer.close()
        with suppress(ConnectionError,OSError):await writer.wait_closed()


async def reverse_channel(channel,url):
    from urllib.parse import urlsplit
    import websockets
    peer=urlsplit(url)
    if (peer.scheme!='wss' or not peer.hostname or peer.username or peer.password or peer.query or peer.fragment):
        raise SessionProtocolError('AGENT_REVERSE_REQUIRES_TLS')
    failures=0
    while True:
        try:
            async with websockets.connect(url,max_size=512000,open_timeout=15,ping_interval=20,ping_timeout=20) as socket:
                async def receive():return json.loads(await socket.recv())
                async def send(value):await socket.send(canonical(value))
                async with asyncio.timeout(15):challenge=await receive()
                if not isinstance(challenge,dict) or challenge.get('type')!='challenge':raise SessionProtocolError('AGENT_HANDSHAKE_INVALID')
                proof=await channel.certificate(challenge['challenge'],challenge['target'])
                await send(dict(type='deviceProof',certificate=proof,provider=channel.runtime.provider))
                await channel.serve(receive,send)
                failures=0
        except (OSError,ValueError,asyncio.TimeoutError,websockets.exceptions.ConnectionClosed):
            failures+=1
        # Reconnect transport only; never replay a mutating native command.
        await asyncio.sleep(min(30,2**min(failures,5)))
