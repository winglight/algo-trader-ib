"""ATI outbound local Agent client; no server entrypoint."""
