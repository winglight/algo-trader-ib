"""Headless outbound Connector. CLI is administration only, never task submission."""

from __future__ import annotations

import argparse
import asyncio
import fcntl
import hashlib
import json
import os
import secrets
import signal
import sys
import time
import webbrowser
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import httpx

VERSION = "local-execution.v2"


def research_capacity():
    """Conservative local budget, never a membership entitlement.

    Respect CPU affinity and cgroup v1/v2 limits. Keep one serial slot when
    resource detection is unavailable; non-root execution stays serial because
    it cannot assign separate task UIDs.
    """
    if os.geteuid() != 0:
        return 1
    cpu = (
        len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
    )
    try:
        quota, period = Path("/sys/fs/cgroup/cpu.max").read_text().split()
        if quota != "max":
            cpu = min(cpu, max(1, int(quota) // int(period)))
    except (OSError, ValueError):
        try:
            quota = int(Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us").read_text())
            period = int(Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us").read_text())
            if quota > 0:
                cpu = min(cpu, max(1, quota // period))
        except (OSError, ValueError):
            cpu = 1
    try:
        memory = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
        for path in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
            try:
                memory = min(memory, int(Path(path).read_text()))
            except (OSError, ValueError):
                pass
        per_task = (
            max(256, int(os.environ.get("ATI_RESEARCH_MEMORY_PER_TASK_MB", "1536"))) * 1024**2
        )
        memory_slots = max(1, (memory - 256 * 1024**2) // per_task)
    except (OSError, ValueError):
        memory_slots = 1
    configured = os.environ.get("ATI_RESEARCH_MAX_PARALLEL", "auto")
    ceiling = 32 if configured == "auto" else max(1, int(configured))
    return max(1, min(32, ceiling, cpu, memory_slots))


def atomic_json(path, value, *, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_suffix(".tmp-" + secrets.token_hex(4))
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as file:
        json.dump(value, file)
        if mode != 0o600:
            os.fchmod(file.fileno(), mode)
    temporary.replace(path)


def installation(directory):
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = root / "installation.json"
    with (root / ".identity.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if path.exists():
            return json.loads(path.read_text())
        value = {"installId": "ati_" + secrets.token_hex(16), "proof": secrets.token_urlsafe(48)}
        value["fingerprint"] = hashlib.sha256(value["proof"].encode()).hexdigest()
        atomic_json(path, value)
        return value


class Connector:
    def __init__(
        self,
        gateway,
        state_dir,
        *,
        component="RESEARCH",
        agent_command=None,
        enable_pool=True,
        read_only_identity=False,
    ):
        parsed = urlsplit(gateway)
        if parsed.scheme != "https" and not (
            parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "testserver"}
        ):
            raise ValueError("CONNECTOR_REQUIRES_TLS")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("INVALID_GATEWAY_URL")
        self.gateway = gateway.rstrip("/")
        self.directory = Path(state_dir)
        self.identity = (
            json.loads((self.directory / "installation.json").read_text())
            if read_only_identity
            else installation(state_dir)
        )
        self.component = component
        self.agent_command = agent_command
        self.http = httpx.AsyncClient(base_url=self.gateway, timeout=30)
        self.pool_root = None
        if (
            enable_pool
            and component == "RESEARCH"
            and os.environ.get("ATI_RESEARCH_EXECUTION_MODE") == "pool"
        ):
            from .local_pool import prepare_pool

            if os.geteuid() != 0:
                raise ValueError("LOCAL_POOL_COORDINATOR_REQUIRES_ROOT")
            self.pool_root = prepare_pool(
                os.environ.get("ATI_RESEARCH_POOL_ROOT", "/var/lib/ati-pool")
            )
            self.max_parallel = max(1, min(32, int(os.environ.get("ATI_RESEARCH_POOL_SIZE", "1"))))
        else:
            self.max_parallel = research_capacity() if component == "RESEARCH" else 1
        self.active = {}
        self.task_root = Path(
            os.environ.get(
                "ATI_RESEARCH_TASK_ROOT", str(self.directory / (self.component.lower() + "-tasks"))
            )
        )
        self.lease_root = Path(
            os.environ.get(
                "ATI_LOCAL_LEASE_ROOT", str(self.directory / (self.component.lower() + "-leases"))
            )
        )

    def task_directory(self, task):
        return self.task_root / task["taskId"] / str(task["attempt"])

    def lease_file(self, task):
        if self.pool_root is not None:
            from .local_pool import task_key

            return self.pool_root / "leases" / (task_key(task) + ".json")
        return self.lease_root / (task["taskId"] + ".json")

    def save_lease(self, task, deadline):
        self.lease_root.mkdir(parents=True, exist_ok=True, mode=0o755)
        path = self.lease_file(task)
        permit = task.get("researchPermit")
        if permit:
            deadline = min(deadline, permit["validUntil"])
        # The unprivileged watchdog must be able to read either version during renewal.
        atomic_json(path, {"deadline": deadline, "researchPermit": permit}, mode=0o644)

    async def post(self, path, payload, *, authenticated=True):
        identity = installation(self.directory)
        headers = {"Authorization": "Bearer " + identity["credential"]} if authenticated else {}
        response = await self.http.post(
            "/cloud/local-execution/" + path, json=payload, headers=headers
        )
        response.raise_for_status()
        return response.json()

    async def connect(self, *, open_browser=True):
        if self.identity.get("credential"):
            return self.identity
        migration_token = self.identity.get("migrationRuntimeToken")
        if migration_token:
            response = await self.http.post(
                "/cloud/local-execution/adopt",
                json={
                    "installId": self.identity["installId"],
                    "fingerprint": self.identity["fingerprint"],
                    "proof": self.identity["proof"],
                },
                headers={"Authorization": "Bearer " + migration_token},
            )
            if response.status_code == 200:
                delivered = response.json()
                grant = delivered.pop("tradingGrant", None)
                if grant:
                    grant["installation"] = {
                        key: self.identity[key] for key in ("installId", "fingerprint")
                    }
                    atomic_json(self.directory / "trading" / "runtime-grant.json", grant)
                self.identity.update(delivered)
                self.identity.pop("migrationRuntimeToken", None)
                atomic_json(self.directory / "installation.json", self.identity)
                return self.identity
            if response.status_code not in {401, 403}:
                response.raise_for_status()
        if not self.identity.get("bindToken"):
            response = await self.http.post(
                "/cloud/local-bind-requests",
                json={
                    "installId": self.identity["installId"],
                    "fingerprint": self.identity["fingerprint"],
                    "name": os.environ.get("ATI_ENVIRONMENT_NAME") or "ATI " + os.uname().nodename,
                    "metadata": {
                        "delivery": "daemon",
                        "proofHash": hashlib.sha256(self.identity["proof"].encode()).hexdigest(),
                    },
                },
            )
            response.raise_for_status()
            url = response.json()["studioUrl"]
            self.identity.update(
                bindToken=parse_qs(urlsplit(url).query)["bindRequest"][0],
                bindingUrl=url,
                bindExpiresAt=response.json()["expiresAt"],
            )
            atomic_json(self.directory / "installation.json", self.identity)
        url = self.identity["bindingUrl"]
        print("Confirm this environment in Cloud Studio:", url, flush=True)
        if open_browser:
            webbrowser.open(url)
        while True:
            result = await self.post(
                "device-delivery",
                {"token": self.identity["bindToken"], "proof": self.identity["proof"]},
                authenticated=False,
            )
            if result.get("status") == "bound":
                self.identity.update(result)
                self.identity.pop("bindingUrl", None)
                self.identity.pop("bindToken", None)
                atomic_json(self.directory / "installation.json", self.identity)
                print("Environment connected:", result["environmentId"], flush=True)
                return self.identity
            if result.get("status") != "pending":
                raise ValueError("BINDING_" + str(result.get("status")))
            await asyncio.sleep(5)

    async def supervise(self, task, command, directory, input_bytes=None):
        """A fenced result is insufficient: kill the old process before releasing capacity."""
        env = {
            k: v
            for k, v in os.environ.items()
            if not (k.startswith(("CLOUD_", "MARIADB_", "REDIS_", "ATI_CONNECTOR_", "ATI_DEVICE_")))
        }
        security = {}
        if task["kind"] != "AI" and os.geteuid() == 0:
            # Drop identity before loading user workflow code. The child cannot
            # read the Connector's 0600 credentials or trading component grant.
            uid = int(os.environ.get("ATI_RESEARCH_EXECUTOR_UID", "65534")) + task.get("_slot", 0)
            directory.parent.chmod(0o755)
            self.task_root.chmod(0o755)
            for path in [directory, *directory.rglob("*")]:
                os.chown(path, uid, uid)
            security = {"user": uid, "group": uid, "extra_groups": []}
        elif task["kind"] != "AI" and os.environ.get("ATI_LOCAL_EXECUTOR_ISOLATION") == "required":
            raise ValueError("LOCAL_EXECUTOR_PRIVILEGE_SEPARATION_REQUIRED")
        command = [
            sys.executable,
            "-m",
            "worker_orchestrator.local_task_process",
            str(self.lease_file(task)),
            *command,
        ]
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=directory,
            env=env,
            **security,
            stdin=asyncio.subprocess.PIPE if input_bytes else asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            start_new_session=True,
        )
        communication = asyncio.create_task(process.communicate(input_bytes))
        try:
            # run() owns the sole renewal task. The subprocess watchdog reads
            # its atomically published deadline even if this process disappears.
            # A second HTTP renewer used a stale private deadline and could kill
            # a task whose lease had just been extended by the first renewer.
            output, errors = await communication
            if process.returncode:
                detail = errors.decode(errors="replace").strip()[-1500:]
                raise RuntimeError(
                    "LOCAL_EXECUTOR_FAILED: "
                    + (detail or f"process exited with code {process.returncode}")
                )
            return output
        finally:
            if process.returncode is None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                except TimeoutError:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    await process.wait()
            # A wrapper can exit before its descendants. Reclaim the entire
            # group before this slot (and its isolated UID) may be reused.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if not communication.done():
                await communication

    async def maintain_task_lease(
        self, task, execution, components, *, clock=time.time, sleep=asyncio.sleep
    ):
        deadline = task["leaseExpiresAt"]
        while not execution.done():
            await sleep(min(20, max(0.1, deadline - clock())))
            if execution.done():
                return
            try:
                value = await self.post(
                    f"tasks/{task['taskId']}/renew", {"leaseId": task["leaseId"]}
                )
                task["leaseExpiresAt"] = value["leaseExpiresAt"]
                task["researchPermit"] = value.get("researchPermit")
                deadline = value["leaseExpiresAt"]
                if task["researchPermit"]:
                    deadline = min(deadline, task["researchPermit"]["validUntil"])
                self.save_lease(task, deadline)
            except httpx.HTTPError as exc:
                permanent = isinstance(
                    exc, httpx.HTTPStatusError
                ) and exc.response.status_code not in {408, 425, 429, 500, 502, 503, 504}
                if permanent or clock() >= deadline:
                    execution.cancel()
                    raise RuntimeError(
                        "LOCAL_EXECUTION_LEASE_LOST" if permanent else "LOCAL_LEASE_EXPIRED_OFFLINE"
                    ) from exc
                continue
            # A failed presence heartbeat cannot revoke a successful task renew.
            try:
                await self.post("heartbeat", {"components": components})
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code in {401, 403}:
                    execution.cancel()
                    raise RuntimeError("LOCAL_EXECUTION_AUTHORIZATION_REVOKED") from exc
            except httpx.HTTPError:
                pass

    async def execute(self, task):
        if task["packet"].get("researchExecution"):
            while True:
                renewed = await self.post(
                    f"tasks/{task['taskId']}/renew", {"leaseId": task["leaseId"]}
                )
                permit = renewed.get("researchPermit")
                if permit:
                    if permit["validUntil"] <= time.time():
                        raise RuntimeError("LOCAL_RESEARCH_PERMIT_EXPIRED")
                    task["researchPermit"] = permit
                    task["leaseExpiresAt"] = renewed["leaseExpiresAt"]
                    break
                await asyncio.sleep(1)
        directory = self.task_directory(task)
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        packet = task["packet"]
        self.save_lease(task, task["leaseExpiresAt"])
        if (
            hashlib.sha256(
                json.dumps(packet, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
            ).hexdigest()
            != task["packetHash"]
        ):
            raise ValueError("LOCAL_PACKET_CHECKSUM_MISMATCH")
        if self.pool_root is not None and task["kind"] != "AI":
            from .local_pool import dispatch

            return await dispatch(self.pool_root, task)
        if task["kind"] == "AI":
            if not self.agent_command:
                raise ValueError("USER_AGENT_ADAPTER_REQUIRED")
            # The child receives only the AI work packet, never a device credential.
            raw = await self.supervise(
                task, self.agent_command, directory, json.dumps(packet).encode()
            )
            result = json.loads(raw)
            if not isinstance(result, dict) or not ("text" in result or "json_payload" in result):
                raise ValueError("AGENT_OUTPUT_CONTRACT_INVALID")
            return result
        if packet.get("dataChunks"):
            raise ValueError(
                "LOCAL_MARKET_DATA_RETRY_REQUIRED: Retry this older task to use your local data."
            )
        database = (
            directory / "bars.sqlite3"
        )  # Legacy argument; user-data tasks read Parquet directly.
        atomic_json(directory / "packet.json", packet)
        await self.supervise(
            task,
            [
                sys.executable,
                "-m",
                "strategy_studio_service.local_native_worker",
                str(directory / "packet.json"),
                str(database),
                str(directory / "result.json"),
                str(self.lease_file(task)),
            ],
            directory,
        )
        return json.loads((directory / "result.json").read_text())

    async def trading_grant(self):
        if not (self.directory / "trading-enabled").exists():
            return
        path = self.directory / "trading" / "runtime-grant.json"
        grant = json.loads(path.read_text()) if path.exists() else {}
        from datetime import datetime

        deadlines = [grant.get("runtimeTokenExpiresAt"), grant.get("lease", {}).get("expiresAt")]
        if (
            all(deadlines)
            and min(datetime.fromisoformat(value).timestamp() for value in deadlines)
            > time.time() + 3600
        ):
            return
        grant = await self.post("trading-grant", {"leaseId": grant.get("lease", {}).get("id")})
        grant["installation"] = {key: self.identity[key] for key in ("installId", "fingerprint")}
        atomic_json(path, grant)

    async def publish_result(self, task_id, receipt):
        try:
            return await self.post(f"tasks/{task_id}/complete", receipt)
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code != 413 or not isinstance(receipt.get("result"), dict):
                raise
            # Preserve the exact completed evidence locally. A deterministic
            # ingress rejection is a technical failure, never permission to
            # expire the lease and compute the same task endlessly.
            atomic_json(
                self.directory
                / (self.component.lower() + "-rejected-outbox")
                / (task_id + ".json"),
                receipt,
            )
            return await self.post(
                f"tasks/{task_id}/complete",
                {
                    "leaseId": receipt["leaseId"],
                    "result": None,
                    "error": (
                        "LOCAL_RESULT_TOO_LARGE: Completion rejected the report; "
                        "exact result retained locally. Report the error before retrying."
                    ),
                },
            )

    async def recover_outbox(self):
        for path in sorted((self.directory / (self.component.lower() + "-outbox")).glob("*.json")):
            if path.stem in self.active:
                continue
            try:
                receipt = json.loads(path.read_text())
                await self.publish_result(path.stem, receipt)
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code not in {404, 409}:
                    raise
                destination = self.directory / (self.component.lower() + "-stale-outbox")
                destination.mkdir(exist_ok=True)
                path.replace(destination / path.name)
            else:
                path.unlink()
                if self.pool_root is not None:
                    from .local_pool import acknowledge

                    acknowledge(self.pool_root, receipt["leaseId"])

    async def handle_task(self, task, components):
        result, error = None, None
        execution = asyncio.create_task(self.execute(task))
        watcher = asyncio.create_task(self.maintain_task_lease(task, execution, components))
        try:
            finished, _ = await asyncio.wait(
                {execution, watcher}, return_when=asyncio.FIRST_COMPLETED
            )
            if watcher in finished:
                await watcher
            result = await execution
        except Exception as exc:
            error = str(exc)[:2000]
        finally:
            watcher.cancel()
            if not execution.done() and not execution.cancelling():
                execution.cancel()
            await asyncio.gather(watcher, execution, return_exceptions=True)
        # Durable outbox: retain exact receipt after uncertain delivery.
        receipt = {"leaseId": task["leaseId"], "result": result, "error": error}
        atomic_json(
            self.directory / (self.component.lower() + "-outbox") / (task["taskId"] + ".json"),
            receipt,
        )
        await self.publish_result(task["taskId"], receipt)
        if self.pool_root is not None:
            from .local_pool import acknowledge

            acknowledge(self.pool_root, task["leaseId"])
        (
            self.directory / (self.component.lower() + "-outbox") / (task["taskId"] + ".json")
        ).unlink()

    async def run(self):
        # One claim loop per installation/component, including across processes.
        with (self.directory / (self.component.lower() + "-runner.lock")).open("a") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise RuntimeError("LOCAL_COMPONENT_ALREADY_RUNNING") from exc
            await self.run_loop()

    async def run_loop(self):
        await self.connect(open_browser=False)
        if self.component == "AGENT" and not self.agent_command:
            raise ValueError("USER_AGENT_ADAPTER_REQUIRED")
        capabilities = {
            "AGENT": ["AI"],
            "TRADING": ["TRADING"],
            "RESEARCH": ["BACKTEST", "SIMULATION", "MONTE_CARLO", "RESEARCH_COMPUTE"],
        }[self.component]
        components = {
            self.component: {
                "capabilities": capabilities,
                "version": VERSION,
                "maxParallel": self.max_parallel,
                "adapter": "stdio-json-v1" if self.component == "AGENT" else "native",
            }
        }
        slots = {}
        try:
            while True:
                try:
                    for task_id, future in list(self.active.items()):
                        if future.done():
                            del self.active[task_id]
                            slots.pop(task_id)
                            await future
                    heartbeat = await self.post("heartbeat", {"components": components})
                    granted = (
                        heartbeat.get("concurrency", {})
                        .get(self.component, {})
                        .get("maxParallel", 1)
                    )
                    limit = max(0, min(self.max_parallel, int(granted)))
                    if self.pool_root is not None:
                        from .local_pool import live_capacity

                        limit = min(limit, live_capacity(self.pool_root, self.max_parallel))
                    try:
                        await self.trading_grant()
                    except httpx.HTTPStatusError as exc:
                        if exc.response.status_code != 403:
                            raise
                    if self.component == "TRADING":
                        await asyncio.sleep(20)
                        continue
                    await self.recover_outbox()
                    while len(self.active) < limit:
                        claimed = await self.post("claim", {"component": self.component})
                        task = claimed.get("task")
                        if not task:
                            break
                        task_id = task["taskId"]
                        if task_id in self.active:
                            # A repeated HTTP delivery must never start a second child.
                            break
                        slot = next(i for i in range(self.max_parallel) if i not in slots.values())
                        task["_slot"] = slot
                        slots[task_id] = slot
                        self.active[task_id] = asyncio.create_task(
                            self.handle_task(task, components)
                        )
                    await asyncio.sleep(3)
                except httpx.HTTPStatusError as exc:
                    if exc.response.status_code in {401, 403}:
                        atomic_json(
                            self.directory / "trading" / "runtime-grant.json", {"status": "revoked"}
                        )
                        raise RuntimeError("ENVIRONMENT_AUTHORIZATION_REVOKED") from exc
                    await asyncio.sleep(5)
                except httpx.HTTPError:
                    await asyncio.sleep(5)
        finally:
            for future in self.active.values():
                future.cancel()
            await asyncio.gather(*self.active.values(), return_exceptions=True)
            self.active.clear()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["connect", "run", "status", "capacity"])
    parser.add_argument("--gateway", required=True)
    parser.add_argument("--state-dir", required=True)
    parser.add_argument("--component", choices=["RESEARCH", "AGENT", "TRADING"], default="RESEARCH")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument(
        "--rebind",
        action="store_true",
        help="Explicitly replace revoked binding; stop other components first",
    )
    parser.add_argument(
        "--agent-command",
        nargs=argparse.REMAINDER,
        help="JSON stdio adapter command; place this option last",
    )
    options = parser.parse_args()

    async def invoke():
        running = asyncio.current_task()
        asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, running.cancel)
        connector = Connector(
            options.gateway,
            options.state_dir,
            component=options.component,
            agent_command=options.agent_command,
            enable_pool=options.action == "run",
            read_only_identity=options.action == "capacity",
        )
        try:
            if options.action == "connect":
                if options.rebind:
                    for key in (
                        "credential",
                        "generation",
                        "environmentId",
                        "expiresAt",
                        "bindToken",
                        "bindingUrl",
                        "bindExpiresAt",
                        "migrationRuntimeToken",
                    ):
                        connector.identity.pop(key, None)
                    connector.identity["proof"] = secrets.token_urlsafe(48)
                    atomic_json(connector.directory / "installation.json", connector.identity)
                await connector.connect(open_browser=not options.no_browser)
            elif options.action == "capacity":
                if not connector.identity.get("credential"):
                    raise RuntimeError("ENVIRONMENT_NOT_CONNECTED")
                response = await connector.http.get(
                    "/cloud/local-execution/capacity",
                    headers={"Authorization": "Bearer " + connector.identity["credential"]},
                )
                response.raise_for_status()
                value = response.json()
                print(
                    json.dumps(
                        {
                            "membershipMaxParallel": int(value["membershipMaxParallel"]),
                            "protocolMaxParallel": int(value["protocolMaxParallel"]),
                        }
                    )
                )
            elif options.action == "run":
                await connector.run()
            else:
                state = installation(options.state_dir)
                print(
                    json.dumps(
                        {
                            "bound": bool(state.get("credential")),
                            "environmentId": state.get("environmentId"),
                        }
                    )
                )
        finally:
            await connector.http.aclose()

    asyncio.run(invoke())


if __name__ == "__main__":
    main()
