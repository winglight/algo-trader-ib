"""Bidirectional Codex App Server transport for container-owned sessions.

Native protocol: https://learn.chatgpt.com/docs/app-server
This is separate from tools-off batch inference. The owner keeps this transport
alive across UI disconnects; failed mutating calls must never be replayed.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
from uuid import uuid4
from collections.abc import Sequence


class AgentOutcomeUnknown(RuntimeError):
    pass


class AgentProtocolError(RuntimeError):
    pass


METHODS = frozenset({'initialize', 'thread/start', 'thread/resume', 'thread/read', 'thread/list',
                     'thread/turns/list', 'thread/items/list', 'thread/fork', 'turn/start',
                     'turn/steer', 'turn/interrupt', 'model/list', 'mcpServerStatus/list'})


class CodexSessionClient:
    def __init__(self, process, *, queue_size=1024):
        self.process = process
        self._events = asyncio.Queue(maxsize=queue_size)
        self.pending = {}
        self.approvals = {}
        self.sequence = 0
        self.write_lock = asyncio.Lock()
        self.closed = False
        self.reader = asyncio.create_task(self._read())

    @classmethod
    async def start(cls, *, cwd: str, command: Sequence[str] | None = None, experimental: bool = False):
        # command injection is reserved for process-level contract tests.
        process = await asyncio.create_subprocess_exec(
            *(command or ['codex', 'app-server', '--listen', 'stdio://']), cwd=cwd,
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL, limit=2 * 1024 * 1024)
        client = cls(process)
        try:
            initialize={'clientInfo': {'name': 'ati_trading_system', 'title': 'ATI Trading System', 'version': '0.2.0'}}
            if experimental:
                initialize['capabilities']={'experimentalApi':True}
            client.info = await client.call('initialize', initialize, timeout=30)
            await client._send({'method': 'initialized', 'params': {}})
            return client
        except BaseException:
            await client.close()
            raise

    async def _send(self, packet):
        async with self.write_lock:
            if self.closed or self.process.returncode is not None:
                raise AgentOutcomeUnknown('AGENT_TRANSPORT_CLOSED')
            try:
                self.process.stdin.write(json.dumps(packet, separators=(',', ':'), allow_nan=False).encode() + b'\n')
                await self.process.stdin.drain()
            except (BrokenPipeError, ConnectionError):
                raise AgentOutcomeUnknown('AGENT_TRANSPORT_LOST') from None

    async def call(self, method, params, *, timeout=120):
        if method not in METHODS:
            raise AgentProtocolError('AGENT_METHOD_NOT_EXPOSED')
        if len(self.pending) >= 128:
            raise AgentProtocolError('AGENT_BACKPRESSURE')
        self.sequence += 1
        identity = self.sequence
        future = asyncio.get_running_loop().create_future()
        self.pending[identity] = future
        try:
            await self._send({'id': identity, 'method': method, 'params': params})
            return await asyncio.wait_for(future, timeout)
        except asyncio.TimeoutError:
            raise AgentOutcomeUnknown('AGENT_RESPONSE_UNKNOWN') from None
        finally:
            self.pending.pop(identity, None)
            if not future.done():
                future.cancel()

    async def next_event(self):
        if self.closed and self._events.empty():
            raise AgentOutcomeUnknown('AGENT_TRANSPORT_LOST')
        getter = asyncio.create_task(self._events.get())
        try:
            await asyncio.wait({getter, self.reader}, return_when=asyncio.FIRST_COMPLETED)
            if getter.done():
                return getter.result()
            raise AgentOutcomeUnknown('AGENT_TRANSPORT_LOST')
        finally:
            if not getter.done():
                getter.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await getter

    async def respond(self, request_id, *, request_token, result):
        pending = self.approvals.get(request_id)
        if pending is None or pending['atiRequestToken'] != request_token:
            raise AgentProtocolError('AGENT_REQUEST_NOT_PENDING')
        json.dumps(result, allow_nan=False)
        # Reserve before awaiting I/O: concurrent clicks cannot send twice.
        self.approvals.pop(request_id)
        await self._send({'id': request_id, 'result': result})

    async def _read(self):
        try:
            while True:
                raw = await self.process.stdout.readline()
                if not raw:
                    break
                packet = json.loads(raw)
                if not isinstance(packet, dict):
                    raise AgentProtocolError('AGENT_INVALID_FRAME')
                if 'id' in packet and type(packet['id']) not in (int, str):
                    raise AgentProtocolError('AGENT_INVALID_FRAME')
                if 'method' in packet:
                    if not isinstance(packet['method'], str) or not isinstance(packet.get('params', {}), dict):
                        raise AgentProtocolError('AGENT_INVALID_FRAME')
                    if 'id' in packet:
                        identity = packet['id']
                        if type(identity) not in (int, str) or identity in self.approvals:
                            raise AgentProtocolError('AGENT_DUPLICATE_REQUEST')
                        packet['atiRequestToken'] = uuid4().hex
                        self.approvals[identity] = packet
                    # Never stall response dispatch behind a slow presentation
                    # consumer. Overflow disconnects with unknown outcomes.
                    if packet['method'] == 'serverRequest/resolved':
                        params = packet.get('params') or {}
                        self.approvals.pop(params.get('requestId'), None)
                    self._events.put_nowait(packet)
                elif 'id' in packet:
                    future = self.pending.get(packet['id'])
                    if future is not None and not future.done():
                        if 'error' in packet:
                            future.set_exception(AgentProtocolError('AGENT_NATIVE_REQUEST_FAILED'))
                        else:
                            future.set_result(packet.get('result'))
        except (ValueError, TypeError, asyncio.QueueFull, AgentProtocolError):
            pass  # exact malformed payloads may contain secrets; do not log
        finally:
            self.closed = True
            for future in list(self.pending.values()):
                if not future.done():
                    future.set_exception(AgentOutcomeUnknown('AGENT_TRANSPORT_LOST'))

    async def close(self):
        self.closed = True
        if self.process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                self.process.terminate()
            try:
                await asyncio.wait_for(self.process.wait(), 5)
            except asyncio.TimeoutError:
                self.process.kill()
                await self.process.wait()
        self.reader.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self.reader
