"""JSON stdio bridge to the user's signed-in Claude Code, with tools disabled.

CLI contract: https://code.claude.com/docs/en/cli-reference
Uses normal subscription authentication; never uses bare mode or handles keys.
"""
import base64
import json
import subprocess
import sys
import tempfile


def attach_images(value, images, *, depth=0):
    if depth > 16:
        raise ValueError('AGENT_INPUT_TOO_DEEP')
    if isinstance(value, dict):
        return {key: attach_images(item, images, depth=depth + 1) for key, item in value.items()}
    if isinstance(value, list):
        return [attach_images(item, images, depth=depth + 1) for item in value]
    if isinstance(value, str) and value.startswith('data:image/'):
        header, data = value.split(',', 1)
        formats = {'data:image/png;base64': 'image/png', 'data:image/jpeg;base64': 'image/jpeg',
                   'data:image/webp;base64': 'image/webp'}
        if header not in formats or len(images) >= 16:
            raise ValueError('AGENT_IMAGE_FORMAT_UNSUPPORTED')
        content = base64.b64decode(data, validate=True)
        if not content or len(content) > 10 * 1024 * 1024:
            raise ValueError('AGENT_IMAGE_TOO_LARGE')
        images.append({'type': 'image', 'source': {'type': 'base64', 'media_type': formats[header], 'data': data}})
        return '[Attached image ' + str(len(images)) + ']'
    if isinstance(value, str) and value[:1] in {'{', '['}:
        try:
            parsed = json.loads(value)
        except ValueError:
            return value
        return json.dumps(attach_images(parsed, images, depth=depth + 1), ensure_ascii=False)
    return value


def main():
    packet = json.load(sys.stdin)
    images = []
    variables = attach_images(packet.get('variables', {}), images)
    prompt = (packet['prompt'] + '\n\nFrozen operation inputs:\n' + json.dumps(variables, ensure_ascii=False)
              + '\n\nReturn the final answer required by the operation. Do not change files or perform trading actions.')
    message = {'type': 'user', 'message': {'role': 'user', 'content': [{'type': 'text', 'text': prompt}, *images]}}
    encoded = json.dumps(message, ensure_ascii=False) + '\n'
    if len(encoded.encode()) > 10 * 1024 * 1024:
        raise ValueError('AGENT_INPUT_TOO_LARGE')
    with tempfile.TemporaryDirectory(prefix='ati-claude-agent-') as work:
        completed = subprocess.run(['claude', '-p', '--safe-mode', '--tools', '', '--disallowedTools', 'mcp__*',
                                   '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
                                   '--no-session-persistence', '--input-format', 'stream-json', '--output-format', 'json'],
                                  input=encoded, text=True, cwd=work, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, check=False)
    if completed.returncode:
        raise ValueError('CLAUDE_EXECUTION_FAILED')
    result = json.loads(completed.stdout)
    if not isinstance(result, dict) or result.get('is_error') or result.get('subtype', 'success') != 'success':
        raise ValueError('CLAUDE_RESULT_REJECTED')
    text = result.get('result')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('CLAUDE_EMPTY_RESULT')
    structured = result.get('structured_output')
    if structured is None:
        try:
            structured = json.loads(text)
        except ValueError:
            pass
    json.dump({'text': text, 'json_payload': structured, 'model': 'user-claude'}, sys.stdout)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError):
        print('Claude adapter failed; check Claude Code login and local diagnostics.', file=sys.stderr)
        raise SystemExit(1)
