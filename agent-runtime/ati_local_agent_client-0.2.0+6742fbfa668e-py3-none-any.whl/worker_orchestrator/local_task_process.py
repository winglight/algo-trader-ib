"""Keep an orphaned task fenced locally even if the Connector is SIGKILLed."""
import json
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path


def main():
    lease_path = Path(sys.argv[1])
    stopped = threading.Event()
    def supervise():
        while not stopped.wait(0.1):
            try:
                deadline = float(json.loads(lease_path.read_text())['deadline'])
            except (OSError, ValueError, KeyError):
                deadline = 0
            if time.time() >= deadline:
                os.killpg(os.getpgrp(), signal.SIGKILL)
    watcher = threading.Thread(target=supervise, daemon=True)
    watcher.start()
    try:
        return subprocess.call(sys.argv[2:])
    finally:
        stopped.set()


if __name__ == '__main__':
    raise SystemExit(main())
