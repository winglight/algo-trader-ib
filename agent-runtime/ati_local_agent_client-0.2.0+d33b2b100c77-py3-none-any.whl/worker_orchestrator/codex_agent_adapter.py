"""JSON stdio bridge to the user's authenticated Codex CLI.

Uses the documented non-interactive command and final-message file:
https://learn.chatgpt.com/docs/non-interactive-mode
No model account, API key, or subscription credential is handled by ATI.
"""
import json
import base64
import subprocess
import sys
import tempfile
from pathlib import Path


def attach_images(value, directory, arguments, *, depth=0):
    """Materialize bounded image inputs, including JSON encoded frozen packets."""
    if depth > 16:
        raise ValueError('AGENT_INPUT_TOO_DEEP')
    if isinstance(value, dict):
        return {key: attach_images(item, directory, arguments, depth=depth + 1) for key, item in value.items()}
    if isinstance(value, list):
        return [attach_images(item, directory, arguments, depth=depth + 1) for item in value]
    if isinstance(value, str) and value.startswith('data:image/'):
        header, data = value.split(',', 1)
        extensions = {'data:image/png;base64': 'png', 'data:image/jpeg;base64': 'jpg', 'data:image/webp;base64': 'webp'}
        if header not in extensions or len(arguments) >= 32:
            raise ValueError('AGENT_IMAGE_FORMAT_UNSUPPORTED')
        content = base64.b64decode(data, validate=True)
        if len(content) > 10 * 1024 * 1024:
            raise ValueError('AGENT_IMAGE_TOO_LARGE')
        path = directory / ('input-' + str(len(arguments)) + '.' + extensions[header])
        path.write_bytes(content)
        arguments.extend(['--image', str(path)])
        return str(path)
    if isinstance(value, str) and value[:1] in {'{', '['}:
        try:
            parsed = json.loads(value)
        except ValueError:
            return value
        return json.dumps(attach_images(parsed, directory, arguments, depth=depth + 1), ensure_ascii=False)
    return value


def main():
    packet = json.load(sys.stdin)
    with tempfile.TemporaryDirectory(prefix='ati-agent-') as work:
        output = Path(work) / 'answer.txt'
        images = []
        variables = attach_images(packet.get('variables', {}), Path(work), images)
        prompt = (packet['prompt'] + '\n\nFrozen operation inputs:\n' +
                  json.dumps(variables, ensure_ascii=False) +
                  '\n\nReturn the final answer required by the operation. Do not change files or perform trading actions.')
        completed = subprocess.run(['codex', 'exec', '--ephemeral', '--skip-git-repo-check', '--sandbox', 'read-only',
                                   '--output-last-message', str(output), *images, '-'],
                                  input=prompt, text=True, cwd=work, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.PIPE, check=False)
        if completed.returncode:
            print('Codex adapter failed; check Codex login and local diagnostics.', file=sys.stderr)
            raise SystemExit(completed.returncode)
        text = output.read_text().strip()
        try:
            structured = json.loads(text)
        except ValueError:
            structured = None
        json.dump({'text': text, 'json_payload': structured, 'model': 'user-codex'}, sys.stdout)


if __name__ == '__main__':
    main()
