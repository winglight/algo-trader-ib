"""Connector protocol journal, not a second Copilot conversation database.

Native IDs, command receipts and unacknowledged transport events survive a
connector restart. A started command is never automatically executed again.
The trading backend remains the owner of Copilot business history.
"""
import hashlib
import json
import sqlite3
import time


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


class SessionProtocolError(ValueError):
    pass


class SessionJournal:
    def __init__(self,path):
        self.db=sqlite3.connect(path,isolation_level=None)
        self.db.row_factory=sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS sessions(owner TEXT, id TEXT, native_id TEXT UNIQUE,
          epoch INTEGER NOT NULL, active_turn TEXT, PRIMARY KEY(owner,id));
        CREATE TABLE IF NOT EXISTS commands(owner TEXT, session_id TEXT, request_id TEXT,
          digest TEXT NOT NULL, state TEXT NOT NULL, result TEXT, created REAL NOT NULL,
          PRIMARY KEY(owner,session_id,request_id));
        CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,
          owner TEXT NOT NULL,session_id TEXT NOT NULL,payload TEXT NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS acks(peer TEXT PRIMARY KEY,seq INTEGER NOT NULL);
        ''')
        # A process crash cannot prove whether an already-sent mutation happened.
        self.db.execute("UPDATE commands SET state='outcome_unknown' WHERE state='started'")

    def close(self):self.db.close()

    def session(self,owner,identity):
        row=self.db.execute('SELECT * FROM sessions WHERE owner=? AND id=?',(owner,identity)).fetchone()
        if row is None:raise SessionProtocolError('AGENT_SESSION_NOT_FOUND')
        return dict(row)

    def reserve(self,owner,identity,request_id,epoch,command):
        digest=hashlib.sha256(canonical(command).encode()).hexdigest()
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row=self.db.execute('SELECT * FROM commands WHERE owner=? AND session_id=? AND request_id=?',(owner,identity,request_id)).fetchone()
            if row:
                if row['digest']!=digest:raise SessionProtocolError('AGENT_IDEMPOTENCY_CONFLICT')
                result=dict(state=row['state'],result=json.loads(row['result']) if row['result'] else None)
            else:
                session=self.db.execute('SELECT epoch FROM sessions WHERE owner=? AND id=?',(owner,identity)).fetchone()
                if session is None:
                    if command['method']!='session.create' or epoch!=1:raise SessionProtocolError('AGENT_SESSION_NOT_FOUND')
                    self.db.execute('INSERT INTO sessions(owner,id,epoch) VALUES (?,?,?)',(owner,identity,epoch))
                elif session['epoch']!=epoch:
                    raise SessionProtocolError('AGENT_WRITER_FENCED')
                self.db.execute("INSERT INTO commands VALUES (?,?,?,?,'started',NULL,?)",(owner,identity,request_id,digest,time.time()))
                result=None
            self.db.execute('COMMIT')
            return result
        except BaseException:
            self.db.execute('ROLLBACK');raise

    def finish(self,owner,identity,request_id,*,state,result):
        self.db.execute('UPDATE commands SET state=?,result=? WHERE owner=? AND session_id=? AND request_id=?',
                        (state,canonical(result),owner,identity,request_id))

    def fence(self,owner,identity,expected,next_epoch):
        if type(next_epoch) is not int or next_epoch!=expected+1:raise SessionProtocolError('AGENT_WRITER_FENCED')
        changed=self.db.execute('UPDATE sessions SET epoch=? WHERE owner=? AND id=? AND epoch=?',(next_epoch,owner,identity,expected))
        if changed.rowcount!=1:raise SessionProtocolError('AGENT_WRITER_FENCED')

    def bind(self,owner,identity,native):
        self.db.execute('UPDATE sessions SET native_id=? WHERE owner=? AND id=? AND native_id IS NULL',(native,owner,identity))
        if self.session(owner,identity)['native_id']!=native:raise SessionProtocolError('AGENT_NATIVE_ID_CHANGED')

    def event(self,native,packet):
        row=self.db.execute('SELECT owner,id FROM sessions WHERE native_id=?',(native,)).fetchone()
        if row is None:return None
        encoded=canonical(packet)
        if len(encoded.encode())>2*1024*1024:raise SessionProtocolError('AGENT_EVENT_TOO_LARGE')
        cursor=self.db.execute('INSERT INTO events(owner,session_id,payload,created) VALUES (?,?,?,?)',(row['owner'],row['id'],encoded,time.time()))
        return cursor.lastrowid

    def events(self,owner,identity,after,limit=100):
        self.session(owner,identity)
        return [dict(sequence=row['seq'],payload=json.loads(row['payload'])) for row in self.db.execute(
            'SELECT seq,payload FROM events WHERE owner=? AND session_id=? AND seq>? ORDER BY seq LIMIT ?',
            (owner,identity,after,min(limit,100)))]

    def acknowledge(self,peer,sequence):
        # Retain the journal for replay/recovery; ACK is a durable delivery cursor.
        self.db.execute('INSERT INTO acks VALUES (?,?) ON CONFLICT(peer) DO UPDATE SET seq=MAX(seq,excluded.seq)',(peer,sequence))
