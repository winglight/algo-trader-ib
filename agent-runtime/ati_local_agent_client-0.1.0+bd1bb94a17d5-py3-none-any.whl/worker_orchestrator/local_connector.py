"""Headless outbound Connector. CLI is administration only, never task submission."""
from __future__ import annotations

import argparse
import fcntl
import asyncio
import hashlib
import json
import os
import secrets
import signal
import sqlite3
import sys
import time
import webbrowser
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import httpx

VERSION = 'local-execution.v2'


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_suffix('.tmp-' + secrets.token_hex(4))
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as file:
        json.dump(value, file)
    temporary.replace(path)


def installation(directory):
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = root / 'installation.json'
    with (root / '.identity.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if path.exists():
            return json.loads(path.read_text())
        value = {'installId': 'ati_' + secrets.token_hex(16), 'proof': secrets.token_urlsafe(48)}
        value['fingerprint'] = hashlib.sha256(value['proof'].encode()).hexdigest()
        atomic_json(path, value)
        return value


class Connector:
    def __init__(self, gateway, state_dir, *, component='RESEARCH', agent_command=None):
        parsed = urlsplit(gateway)
        if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in {'localhost', '127.0.0.1', 'testserver'}):
            raise ValueError('CONNECTOR_REQUIRES_TLS')
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('INVALID_GATEWAY_URL')
        self.gateway = gateway.rstrip('/')
        self.directory = Path(state_dir)
        self.identity = installation(state_dir)
        self.component = component
        self.agent_command = agent_command
        self.http = httpx.AsyncClient(base_url=self.gateway, timeout=30)
        self.process = None
        self.task_root = Path(os.environ.get('ATI_RESEARCH_TASK_ROOT', str(self.directory / (self.component.lower() + '-tasks'))))
        self.lease_root = Path(os.environ.get('ATI_LOCAL_LEASE_ROOT', str(self.directory / (self.component.lower() + '-leases'))))

    def task_directory(self, task):
        return self.task_root / task['taskId'] / str(task['attempt'])

    def lease_file(self, task):
        return self.lease_root / (task['taskId'] + '.json')

    def save_lease(self, task, deadline):
        self.lease_root.mkdir(parents=True, exist_ok=True, mode=0o755)
        path = self.lease_file(task)
        permit = task.get('researchPermit')
        if permit:
            deadline = min(deadline, permit['validUntil'])
        atomic_json(path, {'deadline': deadline, 'researchPermit': permit})
        path.chmod(0o644)

    async def post(self, path, payload, *, authenticated=True):
        identity = installation(self.directory)
        headers = {'Authorization': 'Bearer ' + identity['credential']} if authenticated else {}
        response = await self.http.post('/cloud/local-execution/' + path, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()

    async def connect(self, *, open_browser=True):
        if self.identity.get('credential'):
            return self.identity
        migration_token = self.identity.get('migrationRuntimeToken')
        if migration_token:
            response = await self.http.post('/cloud/local-execution/adopt', json={
                'installId': self.identity['installId'], 'fingerprint': self.identity['fingerprint'],
                'proof': self.identity['proof']}, headers={'Authorization': 'Bearer ' + migration_token})
            if response.status_code == 200:
                delivered = response.json()
                grant = delivered.pop('tradingGrant', None)
                if grant:
                    grant['installation'] = {key: self.identity[key] for key in ('installId', 'fingerprint')}
                    atomic_json(self.directory / 'trading' / 'runtime-grant.json', grant)
                self.identity.update(delivered)
                self.identity.pop('migrationRuntimeToken', None)
                atomic_json(self.directory / 'installation.json', self.identity)
                return self.identity
            if response.status_code not in {401, 403}:
                response.raise_for_status()
        if not self.identity.get('bindToken'):
            response = await self.http.post('/cloud/local-bind-requests', json={
                'installId': self.identity['installId'], 'fingerprint': self.identity['fingerprint'],
                'name': os.environ.get('ATI_ENVIRONMENT_NAME') or 'ATI ' + os.uname().nodename,
                'metadata': {'delivery': 'daemon', 'proofHash': hashlib.sha256(self.identity['proof'].encode()).hexdigest()}})
            response.raise_for_status()
            url = response.json()['studioUrl']
            self.identity.update(bindToken=parse_qs(urlsplit(url).query)['bindRequest'][0], bindingUrl=url,
                                 bindExpiresAt=response.json()['expiresAt'])
            atomic_json(self.directory / 'installation.json', self.identity)
        url = self.identity['bindingUrl']
        print('Confirm this environment in Cloud Studio:', url, flush=True)
        if open_browser:
            webbrowser.open(url)
        while True:
            result = await self.post('device-delivery', {'token': self.identity['bindToken'], 'proof': self.identity['proof']}, authenticated=False)
            if result.get('status') == 'bound':
                self.identity.update(result)
                self.identity.pop('bindingUrl', None)
                self.identity.pop('bindToken', None)
                atomic_json(self.directory / 'installation.json', self.identity)
                print('Environment connected:', result['environmentId'], flush=True)
                return self.identity
            if result.get('status') != 'pending':
                raise ValueError('BINDING_' + str(result.get('status')))
            await asyncio.sleep(5)

    async def supervise(self, task, command, directory, input_bytes=None):
        """A fenced result is insufficient: kill the old process before releasing capacity."""
        env = {k: v for k, v in os.environ.items() if not (k.startswith(('CLOUD_', 'MARIADB_', 'REDIS_', 'ATI_CONNECTOR_', 'ATI_DEVICE_')))}
        security = {}
        if task['kind'] != 'AI' and os.geteuid() == 0:
            # Drop identity before loading user workflow code. The child cannot
            # read the Connector's 0600 credentials or trading component grant.
            uid = int(os.environ.get('ATI_RESEARCH_EXECUTOR_UID', '65534'))
            directory.parent.chmod(0o755)
            self.task_root.chmod(0o755)
            for path in [directory, *directory.rglob('*')]:
                os.chown(path, uid, uid)
            security = {'user': uid, 'group': uid, 'extra_groups': []}
        elif task['kind'] != 'AI' and os.environ.get('ATI_LOCAL_EXECUTOR_ISOLATION') == 'required':
            raise ValueError('LOCAL_EXECUTOR_PRIVILEGE_SEPARATION_REQUIRED')
        command = [sys.executable, '-m', 'worker_orchestrator.local_task_process',
                   str(self.lease_file(task)), *command]
        self.process = await asyncio.create_subprocess_exec(*command, cwd=directory, env=env, **security,
            stdin=asyncio.subprocess.PIPE if input_bytes else asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, start_new_session=True)
        communication = asyncio.create_task(self.process.communicate(input_bytes))
        deadline = task['leaseExpiresAt']
        try:
            while not communication.done():
                done, _ = await asyncio.wait({communication}, timeout=min(20, max(0.1, deadline - time.time())))
                if done:
                    break
                try:
                    renewed = await self.post(f"tasks/{task['taskId']}/renew", {'leaseId': task['leaseId']})
                    deadline = renewed['leaseExpiresAt']
                    task['researchPermit'] = renewed.get('researchPermit')
                    if task['researchPermit']:
                        deadline = min(deadline, task['researchPermit']['validUntil'])
                    self.save_lease(task, deadline)
                except httpx.HTTPStatusError:
                    raise RuntimeError('LOCAL_LEASE_LOST')
                except httpx.HTTPError:
                    if time.time() >= deadline:
                        raise RuntimeError('LOCAL_LEASE_EXPIRED_OFFLINE')
            output, errors = await communication
            if self.process.returncode:
                raise RuntimeError('LOCAL_EXECUTOR_FAILED: ' + errors.decode(errors='replace')[-1500:])
            return output
        finally:
            if self.process.returncode is None:
                os.killpg(self.process.pid, signal.SIGTERM)
                try:
                    await asyncio.wait_for(self.process.wait(), timeout=5)
                except TimeoutError:
                    os.killpg(self.process.pid, signal.SIGKILL)
                    await self.process.wait()
            if not communication.done():
                await communication
            self.process = None

    async def prepare_data(self, task, directory):
        database = directory / 'bars.sqlite3'
        with sqlite3.connect(database) as db:
            db.execute('CREATE TABLE IF NOT EXISTS bars (symbol TEXT, timeframe TEXT, clock REAL, body TEXT, PRIMARY KEY(symbol,timeframe,clock))')
            for chunk in task['packet'].get('dataChunks', []):
                path = directory / (chunk['sha256'] + '.json')
                data = path.read_bytes() if path.exists() else None
                if data is None or hashlib.sha256(data).hexdigest() != chunk['sha256']:
                    response = await self.http.get(f"/strategy-studio/local-execution/data/{task['taskId']}/{chunk['sha256']}",
                        headers={'Authorization': 'Bearer ' + installation(self.directory)['credential'], 'X-Local-Lease-Id': task['leaseId']})
                    response.raise_for_status()
                    data = response.content
                    if len(data) != chunk['sizeBytes'] or hashlib.sha256(data).hexdigest() != chunk['sha256']:
                        raise ValueError('LOCAL_DATA_CHECKSUM_MISMATCH')
                    path.write_bytes(data)
                rows = json.loads(data)
                if len(rows) != chunk['rows']:
                    raise ValueError('LOCAL_DATA_ROW_COUNT_MISMATCH')
                from datetime import datetime
                for row in rows:
                    timestamp = datetime.fromisoformat(str(row['timestamp']).replace('Z', '+00:00')).timestamp()
                    encoded = json.dumps(row, sort_keys=True)
                    previous = db.execute('SELECT body FROM bars WHERE symbol=? AND timeframe=? AND clock=?',
                        (chunk['symbol'], chunk['timeframe'], timestamp)).fetchone()
                    if previous and previous[0] != encoded:
                        raise ValueError('LOCAL_DATA_CONFLICTING_DUPLICATE')
                    db.execute('INSERT OR IGNORE INTO bars VALUES (?,?,?,?)',
                        (chunk['symbol'], chunk['timeframe'], timestamp, encoded))
            db.commit()
        return database

    async def execute(self, task):
        if task['packet'].get('researchExecution'):
            while True:
                renewed = await self.post(f"tasks/{task['taskId']}/renew", {'leaseId': task['leaseId']})
                permit = renewed.get('researchPermit')
                if permit:
                    if permit['validUntil'] <= time.time():
                        raise RuntimeError('LOCAL_RESEARCH_PERMIT_EXPIRED')
                    task['researchPermit'] = permit
                    task['leaseExpiresAt'] = renewed['leaseExpiresAt']
                    break
                await asyncio.sleep(1)
        directory = self.task_directory(task)
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        packet = task['packet']
        self.save_lease(task, task['leaseExpiresAt'])
        if hashlib.sha256(json.dumps(packet, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest() != task['packetHash']:
            raise ValueError('LOCAL_PACKET_CHECKSUM_MISMATCH')
        if task['kind'] == 'AI':
            if not self.agent_command:
                raise ValueError('USER_AGENT_ADAPTER_REQUIRED')
            # The child receives only the AI work packet, never a device credential.
            raw = await self.supervise(task, self.agent_command, directory,
                                       json.dumps(packet).encode())
            result = json.loads(raw)
            if not isinstance(result, dict) or not ('text' in result or 'json_payload' in result):
                raise ValueError('AGENT_OUTPUT_CONTRACT_INVALID')
            return result
        database = await self.prepare_data(task, directory)
        atomic_json(directory / 'packet.json', packet)
        await self.supervise(task, [sys.executable, '-m', 'strategy_studio_service.local_native_worker',
            str(directory / 'packet.json'), str(database), str(directory / 'result.json'), str(self.lease_file(task))], directory)
        return json.loads((directory / 'result.json').read_text())

    async def trading_grant(self):
        if not (self.directory / 'trading-enabled').exists():
            return
        path = self.directory / 'trading' / 'runtime-grant.json'
        grant = json.loads(path.read_text()) if path.exists() else {}
        from datetime import datetime
        deadlines = [grant.get('runtimeTokenExpiresAt'), grant.get('lease', {}).get('expiresAt')]
        if all(deadlines) and min(datetime.fromisoformat(value).timestamp() for value in deadlines) > time.time() + 3600:
            return
        grant = await self.post('trading-grant', {'leaseId': grant.get('lease', {}).get('id')})
        grant['installation'] = {key: self.identity[key] for key in ('installId', 'fingerprint')}
        atomic_json(path, grant)

    async def recover_outbox(self):
        for path in sorted((self.directory / (self.component.lower() + '-outbox')).glob('*.json')):
            try:
                await self.post(f'tasks/{path.stem}/complete', json.loads(path.read_text()))
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code not in {404, 409}:
                    raise
                destination = self.directory / (self.component.lower() + '-stale-outbox')
                destination.mkdir(exist_ok=True)
                path.replace(destination / path.name)
            else:
                path.unlink()

    async def run(self):
        await self.connect(open_browser=False)
        if self.component == 'AGENT' and not self.agent_command:
            raise ValueError('USER_AGENT_ADAPTER_REQUIRED')
        capabilities = {
            'AGENT': ['AI'],
            'TRADING': ['TRADING'],
            'RESEARCH': ['BACKTEST', 'SIMULATION', 'MONTE_CARLO', 'RESEARCH_COMPUTE'],
        }[self.component]
        components = {self.component: {'capabilities': capabilities, 'version': VERSION, 'maxParallel': 1,
                                      'adapter': 'stdio-json-v1' if self.component == 'AGENT' else 'native'}}
        while True:
            try:
                await self.post('heartbeat', {'components': components})
                try:
                    await self.trading_grant()
                except httpx.HTTPStatusError as exc:
                    if exc.response.status_code != 403:
                        raise
                    # A research-only account is bound, but trading still needs
                    # its own feature entitlement.
                if self.component == 'TRADING':
                    # Trading-only installations still need the single grant
                    # writer, but must never advertise or claim research work.
                    await asyncio.sleep(20)
                    continue
                await self.recover_outbox()
                claimed = await self.post('claim', {'component': self.component})
                task = claimed.get('task')
                if task:
                    result, error = None, None
                    execution = asyncio.create_task(self.execute(task))
                    async def maintain_lease():
                        deadline = task['leaseExpiresAt']
                        while not execution.done():
                            await asyncio.sleep(min(20, max(0.1, deadline - time.time())))
                            try:
                                value = await self.post(f"tasks/{task['taskId']}/renew", {'leaseId': task['leaseId']})
                                deadline = value['leaseExpiresAt']
                                task['researchPermit'] = value.get('researchPermit')
                                if task['researchPermit']:
                                    deadline = min(deadline, task['researchPermit']['validUntil'])
                                self.save_lease(task, deadline)
                                await self.post('heartbeat', {'components': components})
                            except httpx.HTTPError as exc:
                                if isinstance(exc, httpx.HTTPStatusError) or time.time() >= deadline:
                                    execution.cancel()
                                    raise RuntimeError('LOCAL_EXECUTION_LEASE_LOST') from exc
                    watcher = asyncio.create_task(maintain_lease())
                    try:
                        finished, _ = await asyncio.wait({execution, watcher}, return_when=asyncio.FIRST_COMPLETED)
                        if watcher in finished:
                            await watcher
                        result = await execution
                    except (ValueError, RuntimeError, httpx.HTTPError) as exc:
                        error = str(exc)[:2000]
                    finally:
                        watcher.cancel()
                        if not execution.done():
                            execution.cancel()
                        await asyncio.gather(watcher, execution, return_exceptions=True)
                    # Durable outbox: retain exact receipt after uncertain delivery.
                    receipt = {'leaseId': task['leaseId'], 'result': result, 'error': error}
                    atomic_json(self.directory / (self.component.lower() + '-outbox') / (task['taskId'] + '.json'), receipt)
                    await self.post(f"tasks/{task['taskId']}/complete", receipt)
                    (self.directory / (self.component.lower() + '-outbox') / (task['taskId'] + '.json')).unlink()
                else:
                    await asyncio.sleep(3)
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code in {401, 403}:
                    atomic_json(self.directory / 'trading' / 'runtime-grant.json', {'status': 'revoked'})
                    raise RuntimeError('ENVIRONMENT_AUTHORIZATION_REVOKED') from exc
                await asyncio.sleep(5)
            except httpx.HTTPError:
                await asyncio.sleep(5)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['connect', 'run', 'status'])
    parser.add_argument('--gateway', required=True)
    parser.add_argument('--state-dir', required=True)
    parser.add_argument('--component', choices=['RESEARCH', 'AGENT', 'TRADING'], default='RESEARCH')
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--rebind', action='store_true', help='Explicitly replace revoked binding; stop other components first')
    parser.add_argument('--agent-command', nargs=argparse.REMAINDER, help='JSON stdio adapter command; place this option last')
    options = parser.parse_args()
    async def invoke():
        connector = Connector(options.gateway, options.state_dir, component=options.component,
                              agent_command=options.agent_command)
        try:
            if options.action == 'connect':
                if options.rebind:
                    for key in ('credential', 'generation', 'environmentId', 'expiresAt', 'bindToken', 'bindingUrl', 'bindExpiresAt', 'migrationRuntimeToken'):
                        connector.identity.pop(key, None)
                    connector.identity['proof'] = secrets.token_urlsafe(48)
                    atomic_json(connector.directory / 'installation.json', connector.identity)
                await connector.connect(open_browser=not options.no_browser)
            elif options.action == 'run':
                await connector.run()
            else:
                state = installation(options.state_dir)
                print(json.dumps({'bound': bool(state.get('credential')), 'environmentId': state.get('environmentId')}))
        finally:
            await connector.http.aclose()
    asyncio.run(invoke())


if __name__ == '__main__':
    main()
